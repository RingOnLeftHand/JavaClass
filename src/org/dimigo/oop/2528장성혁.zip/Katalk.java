package org.dimigo.oop;

import java.util.*;


public class Katalk {

    public Katalk() {
    }


    private int friend_su=490415676;


    private String myname="뺘";

    private String profile="고2";

    private String chat="100만개이상의채팅방";

    private String friend_name="김우쥬";

    public void send(String Go) {
        System.out.println("보내버려따");
    }

    public void resend(String GoGo) {
        System.out.println("답장해버렷따");
    }

    public void delete() {
        System.out.println("삭제해버려따");
    }
    public void out() {
        System.out.println("채팅방나가버려따");
    }

    public void invite() {
        System.out.println("초대해버려따");
    }

}